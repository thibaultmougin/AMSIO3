#! /usr/bin/env python
# -*- coding: utf-8 -*-

import subprocess


subprocess.call(['python3', 'plot.py'])
